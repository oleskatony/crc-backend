import boto3

dynamodb = boto3.resource('dynamodb')
table_name = 'VisitorCounter'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    table.update_item(
        Key={'visit_counter': 'counter'},
        UpdateExpression='ADD visitors :val',
        ExpressionAttributeValues={':val': 1}
    )

    response = {
        'statusCode': 200,
        'body': 'Visitor count updated successfully'
    }

    return response